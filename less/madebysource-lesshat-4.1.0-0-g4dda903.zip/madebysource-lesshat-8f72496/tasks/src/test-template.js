var assert = require('assert');

describe('{{ mixin_css_name }}', function () {
	it('should return the same value', function (done) {
		test.{{ mixin_name }}('something', 'something', done);
	});
});
