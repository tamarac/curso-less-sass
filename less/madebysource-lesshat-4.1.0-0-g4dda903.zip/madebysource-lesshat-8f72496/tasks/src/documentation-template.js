### <a name="{{ mixin_name }}"></a> &#8226; {{ mixin_name }}
**Summary:**

Lorem ipsum...

Resources: **[MDN](https://developer.mozilla.org/en-US/docs/Web/CSS/{{ mixin_name }})**

**Syntax:**

Default value: 0

    .{{ mixin_name }}(TODO)
  
**Example:**

    div {
     .{{ mixin_name }}(TODO);
    }
    
    // Result
    div {
     -webkit-{{ mixin_name }}: TODO;
    } 
