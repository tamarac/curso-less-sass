var assert = require('assert');

describe('background-clip', function() {

  it('should return the same value', function(done) {
    test.backgroundClip('padding-box', 'padding-box', done);
  });

});