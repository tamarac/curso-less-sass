var assert = require('assert');

describe('hyphens', function() {

  it('should return the same value', function(done) {
    test.hyphens('none', 'none', done);
  });

});
